import { motion } from "framer-motion";
import { DelayedLink } from "../Elements/Link";
import { Product } from "~/hooks/interfaces";
import { Subcategory } from "~/hooks/useProductSubCategories";
import { parseTextWithMainColor } from "../utils";

export const Breadcrumbs = ({
  category,
  subcategory,
  product,
}: {
  category: string;
  product: Product;
  subcategory: Subcategory;
}) => {
  return (
    <motion.nav
      initial={{ y: -10, opacity: 0 }}
      whileInView={{ y: 0, opacity: 1 }}
      transition={{ duration: 1, ease: "easeInOut", delay: 1.2 }}
      viewport={{ amount: 0.3, once: true }}
      className="flex"
      aria-label="Breadcrumb"
    >
      <ol className="flex-wrap mx-auto pb-8 inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse justify-center">
        <li className="inline-flex items-center">
          <DelayedLink
            to="/"
            className="inline-flex items-center text-sm font-medium text-gray-700 hover:text-singula-main"
          >
            <svg
              className="w-3 h-3 me-2.5"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
            </svg>
            Início
          </DelayedLink>
        </li>
        <li>
          <div className="flex items-center">
            <svg
              className="rtl:rotate-180 w-3 h-3 text-gray-400 mx-1"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 6 10"
            >
              <path
                stroke="currentColor"
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="m1 9 4-4-4-4"
              />
            </svg>
            <DelayedLink
              to={`/products/`}
              className="ms-1 text-sm font-medium text-gray-700 hover:text-singula-main"
            >
              Produtos
            </DelayedLink>
          </div>
        </li>
        <li>
          <div className="flex items-center">
            <svg
              className="rtl:rotate-180 w-3 h-3 text-gray-400 mx-1"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 6 10"
            >
              <path
                stroke="currentColor"
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="m1 9 4-4-4-4"
              />
            </svg>
            <DelayedLink
              to={`/products/${subcategory.category.slug}`}
              className="ms-1 text-sm font-medium text-gray-700 hover:text-singula-main"
            >
              {subcategory.category.title}
            </DelayedLink>
          </div>
        </li>
        <li aria-current="page">
          <div className="flex items-center">
            <svg
              className="rtl:rotate-180 w-3 h-3 text-gray-400 mx-1"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 6 10"
            >
              <path
                stroke="currentColor"
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="m1 9 4-4-4-4"
              />
            </svg>
            <span className="ms-1 text-sm font-medium text-gray-500 md:ms-2 dark:text-gray-400">
              {parseTextWithMainColor(product.name)}
            </span>
          </div>
        </li>
      </ol>
    </motion.nav>
  );
};
