import PocketBase from "pocketbase";

const pb = new PocketBase("http://185.11.167.133:8090"); // or your API URL

export default pb;
